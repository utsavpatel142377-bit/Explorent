/**
 * ===================================================================
 * Explorent Gaming Magazine & Marwadi University
 * Form Validation Script with JavaScript Alert Popups
 * -------------------------------------------------------------------
 * Requirements Implemented with Alert Popups:
 *  1. All fields required (alert if any field is empty)
 *  2. Password length (minimum 8 characters alert)
 *  3. Email pattern (@marwadiuniversity.ac.in domain required alert)
 *  4. Password pattern (at least 1 uppercase, 1 lowercase, 1 digit, 1 special character alert)
 *  5. Phone number pattern (valid 10-digit number starting with 6-9 alert)
 * ===================================================================
 */

'use strict';

// Regular Expression Patterns
const VALIDATION_PATTERNS = {
	// Must end with @marwadiuniversity.ac.in
	email: /^[a-zA-Z0-9._%+-]+@marwadiuniversity\.ac\.in$/i,

	// Valid 10-digit phone number, optionally with +91 or 0 prefix, starting with 6, 7, 8, or 9
	phone: /^(?:\+91[\-\s]?|0)?[6-9]\d{9}$/,

	// Password individual patterns
	passwordUpper: /[A-Z]/,
	passwordLower: /[a-z]/,
	passwordNumber: /[0-9]/,
	passwordSpecial: /[!@#$%^&*(),.?":{}|<>_\-\\\/+=~`\[\]]/,

	// Full combined password regex (min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special char)
	passwordFull: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>_\-\\\/+=~`\[\]]).{8,}$/
};

/**
 * Validate an individual field
 * @param {HTMLElement|string} inputEl 
 * @param {boolean} showAlert - Whether to trigger alert() popup on failure
 * @returns {object} { isValid: boolean, message: string, field: HTMLElement }
 */
function validateField(inputEl, showAlert = false) {
	const field = typeof inputEl === 'string' ? document.getElementById(inputEl) : inputEl;
	if (!field) return { isValid: true, message: '', field: null };

	const value = field.value.trim();
	const fieldName = field.getAttribute('data-name') || field.placeholder || field.name || field.id || 'Field';
	const errorContainer = document.getElementById(field.id + '-error');

	let isValid = true;
	let errorMessage = '';

	// -------------------------------------------------------------
	// 1. ALL FIELDS REQUIRED
	// -------------------------------------------------------------
	if (field.hasAttribute('required') || field.classList.contains('validate-required')) {
		if (value === '') {
			isValid = false;
			errorMessage = `Validation Error: All fields are required!\n\nPlease fill in the "${fieldName}" field.`;
			setFieldState(field, errorContainer, false, `${fieldName} is required and cannot be empty.`);
			if (showAlert) {
				alert(errorMessage);
				field.focus();
			}
			return { isValid: false, message: errorMessage, field: field };
		}
	}

	// Skip pattern checks if non-required field is empty
	if (value === '') {
		setFieldState(field, errorContainer, true, '');
		return { isValid: true, message: '', field: field };
	}

	// -------------------------------------------------------------
	// 3. EMAIL PATTERN (@marwadiuniversity.ac.in)
	// -------------------------------------------------------------
	if (field.type === 'email' || field.id.toLowerCase().includes('email') || field.name.toLowerCase().includes('email')) {
		if (!VALIDATION_PATTERNS.email.test(value)) {
			isValid = false;
			errorMessage = `Validation Error: Email Pattern Mismatch!\n\nEmail must belong to Marwadi University and end with:\n@marwadiuniversity.ac.in\n\nExample:\nstudent@marwadiuniversity.ac.in`;
			setFieldState(field, errorContainer, false, 'Email must end with @marwadiuniversity.ac.in');
			if (showAlert) {
				alert(errorMessage);
				field.focus();
			}
			return { isValid: false, message: errorMessage, field: field };
		}
	}

	// -------------------------------------------------------------
	// 5. PHONE NUMBER PATTERN
	// -------------------------------------------------------------
	if (field.type === 'tel' || field.id.toLowerCase().includes('phone') || field.name.toLowerCase().includes('phone')) {
		const cleanPhone = value.replace(/[\s\-]/g, '');
		if (!VALIDATION_PATTERNS.phone.test(cleanPhone)) {
			isValid = false;
			errorMessage = `Validation Error: Phone Number Pattern Mismatch!\n\nPhone number must be a valid 10-digit number starting with 6, 7, 8, or 9.\n\nExample:\n9876543210`;
			setFieldState(field, errorContainer, false, 'Phone must be a valid 10-digit number starting with 6, 7, 8, or 9.');
			if (showAlert) {
				alert(errorMessage);
				field.focus();
			}
			return { isValid: false, message: errorMessage, field: field };
		}
	}

	// -------------------------------------------------------------
	// 2 & 4. PASSWORD LENGTH & PASSWORD PATTERN
	// -------------------------------------------------------------
	if (field.type === 'password' && (field.id.toLowerCase().includes('password') || field.name.toLowerCase().includes('password'))) {
		// Confirm Password check
		if (field.id.toLowerCase().includes('confirm') || field.name.toLowerCase().includes('confirm')) {
			const originalPwdId = field.getAttribute('data-match') || 'password';
			const originalPasswordField = document.getElementById(originalPwdId) || document.querySelector('input[type="password"]:not([id*="confirm"])');
			if (originalPasswordField && value !== originalPasswordField.value) {
				isValid = false;
				errorMessage = `Validation Error: Password Mismatch!\n\nPassword and Confirm Password do not match. Please re-enter identical passwords.`;
				setFieldState(field, errorContainer, false, 'Passwords do not match.');
				if (showAlert) {
					alert(errorMessage);
					field.focus();
				}
				return { isValid: false, message: errorMessage, field: field };
			}
		} else {
			// Update live checklist if present on page
			updatePasswordChecklist(value);

			// Rule 2: Password Length (at least 8 characters)
			if (value.length < 8) {
				isValid = false;
				errorMessage = `Validation Error: Password Length Requirement Not Met!\n\nPassword must be at least 8 characters long.\n(Current length: ${value.length} characters)`;
				setFieldState(field, errorContainer, false, `Password must be at least 8 characters (currently ${value.length}).`);
				if (showAlert) {
					alert(errorMessage);
					field.focus();
				}
				return { isValid: false, message: errorMessage, field: field };
			}

			// Rule 4: Password Pattern
			let missingParts = [];
			if (!VALIDATION_PATTERNS.passwordUpper.test(value)) {
				missingParts.push('• At least one uppercase letter (A-Z)');
			}
			if (!VALIDATION_PATTERNS.passwordLower.test(value)) {
				missingParts.push('• At least one lowercase letter (a-z)');
			}
			if (!VALIDATION_PATTERNS.passwordNumber.test(value)) {
				missingParts.push('• At least one digit/number (0-9)');
			}
			if (!VALIDATION_PATTERNS.passwordSpecial.test(value)) {
				missingParts.push('• At least one special character (!@#$%^&*...)');
			}

			if (missingParts.length > 0) {
				isValid = false;
				errorMessage = `Validation Error: Password Pattern Requirement Not Met!\n\nYour password must include:\n${missingParts.join('\n')}`;
				setFieldState(field, errorContainer, false, 'Password does not meet required complexity patterns.');
				if (showAlert) {
					alert(errorMessage);
					field.focus();
				}
				return { isValid: false, message: errorMessage, field: field };
			}
		}
	}

	setFieldState(field, errorContainer, true, '');
	return { isValid: true, message: '', field: field };
}

/**
 * Apply visual state (valid/invalid class & message) to a field
 */
function setFieldState(field, errorContainer, isValid, message) {
	if (isValid) {
		field.classList.remove('is-invalid');
		field.classList.add('is-valid');
		if (errorContainer) {
			errorContainer.textContent = '';
			errorContainer.style.display = 'none';
		}
	} else {
		field.classList.remove('is-valid');
		field.classList.add('is-invalid');
		if (errorContainer) {
			errorContainer.textContent = message;
			errorContainer.style.display = 'block';
		}
	}
}

/**
 * Live Password Strength & Checklist Helper
 */
function updatePasswordChecklist(password) {
	const ruleLength = document.getElementById('pwd-rule-length');
	const ruleUpper = document.getElementById('pwd-rule-upper');
	const ruleLower = document.getElementById('pwd-rule-lower');
	const ruleNumber = document.getElementById('pwd-rule-number');
	const ruleSpecial = document.getElementById('pwd-rule-special');
	const strengthBar = document.getElementById('password-strength-bar');

	let passedRules = 0;

	if (password.length >= 8) {
		passedRules++;
		if (ruleLength) setRulePassed(ruleLength, true);
	} else {
		if (ruleLength) setRulePassed(ruleLength, false);
	}

	if (VALIDATION_PATTERNS.passwordUpper.test(password)) {
		passedRules++;
		if (ruleUpper) setRulePassed(ruleUpper, true);
	} else {
		if (ruleUpper) setRulePassed(ruleUpper, false);
	}

	if (VALIDATION_PATTERNS.passwordLower.test(password)) {
		passedRules++;
		if (ruleLower) setRulePassed(ruleLower, true);
	} else {
		if (ruleLower) setRulePassed(ruleLower, false);
	}

	if (VALIDATION_PATTERNS.passwordNumber.test(password)) {
		passedRules++;
		if (ruleNumber) setRulePassed(ruleNumber, true);
	} else {
		if (ruleNumber) setRulePassed(ruleNumber, false);
	}

	if (VALIDATION_PATTERNS.passwordSpecial.test(password)) {
		passedRules++;
		if (ruleSpecial) setRulePassed(ruleSpecial, true);
	} else {
		if (ruleSpecial) setRulePassed(ruleSpecial, false);
	}

	if (strengthBar) {
		const percentage = (passedRules / 5) * 100;
		strengthBar.style.width = percentage + '%';

		if (passedRules <= 2) {
			strengthBar.className = 'progress-bar bg-danger';
		} else if (passedRules <= 4) {
			strengthBar.className = 'progress-bar bg-warning';
		} else {
			strengthBar.className = 'progress-bar bg-success';
		}
	}
}

function setRulePassed(element, isPassed) {
	if (isPassed) {
		element.classList.remove('text-muted', 'text-danger');
		element.classList.add('text-success');
		const icon = element.querySelector('i');
		if (icon) {
			icon.className = 'fa fa-check-circle mr-1';
		}
	} else {
		element.classList.remove('text-success');
		element.classList.add('text-muted');
		const icon = element.querySelector('i');
		if (icon) {
			icon.className = 'fa fa-circle-o mr-1';
		}
	}
}

/**
 * Validate an entire form with Alert Popups
 * @param {HTMLFormElement|string} formEl 
 * @param {boolean} showAlert - Trigger alert popup
 * @returns {boolean} true if all fields are valid, false otherwise
 */
function validateForm(formEl, showAlert = true) {
	const form = typeof formEl === 'string' ? document.getElementById(formEl) : formEl;
	if (!form) return false;

	const inputs = form.querySelectorAll('input, select, textarea');

	// Step 1: Validate each field in sequential DOM order.
	// Stop at the FIRST failure and trigger the specific alert popup!
	for (let i = 0; i < inputs.length; i++) {
		const input = inputs[i];
		if (['submit', 'button', 'reset', 'hidden'].includes(input.type)) continue;

		const result = validateField(input, showAlert);
		if (!result.isValid) {
			return false; // Stop immediately on first failed rule
		}
	}

	// Step 2: If all validations pass, show success alert!
	if (showAlert) {
		alert(
			"Validation Success!\n\n" +
			"All criteria verified successfully:\n" +
			"  1. All required fields are filled.\n" +
			"  2. Password length is valid (>= 8 characters).\n" +
			"  3. Email pattern is verified (@marwadiuniversity.ac.in).\n" +
			"  4. Password pattern verified (Uppercase, Lowercase, Number, Special Character).\n" +
			"  5. Phone number pattern is verified (10 digits starting with 6-9)."
		);
	}

	return true;
}

/**
 * Attach automatic real-time feedback and submit alert popups to forms
 */
document.addEventListener('DOMContentLoaded', function () {
	const forms = document.querySelectorAll('.needs-validation-custom');

	forms.forEach(form => {
		const inputs = form.querySelectorAll('input, select, textarea');

		// Attach input and blur listeners for live visual feedback
		inputs.forEach(input => {
			if (['submit', 'button', 'reset', 'hidden'].includes(input.type)) return;

			input.addEventListener('input', function () {
				validateField(this, false); // No popup while typing
			});

			input.addEventListener('blur', function () {
				validateField(this, false); // No popup on blur
			});
		});

		// On form submit, trigger the alert popups!
		form.addEventListener('submit', function (e) {
			e.preventDefault();

			// Validate with popup alert enabled
			const isValid = validateForm(this, true);

			const alertBox = document.getElementById(this.id + '-alert') || form.querySelector('.form-status-alert');

			if (isValid) {
				if (alertBox) {
					alertBox.className = 'alert alert-success d-flex align-items-center show mt-3';
					alertBox.innerHTML = `
						<i class="fa fa-check-circle fa-2x mr-3 text-success"></i>
						<div>
							<strong>Validation Passed!</strong><br>
							All fields verified according to Marwadi University requirements. Account registered successfully!
						</div>
					`;
					alertBox.style.display = 'flex';
				}

				// Trigger success callback if defined
				if (typeof onRegistrationSuccess === 'function') {
					onRegistrationSuccess(form);
				}
			} else {
				if (alertBox) {
					alertBox.className = 'alert alert-danger d-flex align-items-center show mt-3';
					alertBox.innerHTML = `
						<i class="fa fa-exclamation-triangle fa-2x mr-3 text-danger"></i>
						<div>
							<strong>Validation Error!</strong><br>
							Please correct the highlighted fields and retry.
						</div>
					`;
					alertBox.style.display = 'flex';
				}
			}
		});
	});
});
